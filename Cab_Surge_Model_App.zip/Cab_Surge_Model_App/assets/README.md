# Assets

Reserved for screenshots, visuals, and exported charts. The current interface uses embedded CSS in `app.py`.
