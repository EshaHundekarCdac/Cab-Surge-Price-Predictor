# Cab Surge Price Predictor

This Streamlit project uses your trained `best_cab_predictor_pipeline.pkl` model and your cab surge predictor notebook.

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

Or double-click `RUN_PROJECT.bat` on Windows.

## Included

- `app.py` - modern Streamlit frontend
- `cab_surge_predictor.ipynb` - copied source notebook
- `model/best_cab_predictor_pipeline.pkl` - trained ML pipeline
- `dataset/cab_surge_dashboard_dataset.csv` - dashboard and prediction reference dataset

## Features

- Home overview
- Analytics dashboard
- Real ML price prediction
- Clustering analysis
- Business insights
- KPI cards and interactive Plotly charts
