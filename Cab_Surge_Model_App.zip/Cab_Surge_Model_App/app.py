from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from sklearn.cluster import KMeans
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "dataset" / "cab_surge_dashboard_dataset.csv"
MODEL_PATH = BASE_DIR / "model" / "best_cab_predictor_pipeline.pkl"

MODEL_FEATURES = [
    "distance",
    "temp",
    "rain",
    "clouds",
    "hour",
    "is_rush_hour",
    "cab_type",
    "name",
    "Day_of_Week_Name",
]

DAY_ORDER = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


st.set_page_config(page_title="Cab Surge Price Predictor", layout="wide")


def css() -> None:
    st.markdown(
        """
        <style>
        .stApp {
            background:
                radial-gradient(circle at 8% 8%, rgba(0, 194, 255, .16), transparent 28rem),
                radial-gradient(circle at 92% 4%, rgba(255, 92, 124, .14), transparent 30rem),
                linear-gradient(135deg, #071019, #111827 45%, #080d14);
            color: #f7fbff;
        }
        section[data-testid="stSidebar"] {
            background: linear-gradient(180deg, #050914, #121a2a);
            border-right: 1px solid rgba(255,255,255,.08);
        }
        .block-container { padding-top: 1.1rem; }
        .hero {
            border: 1px solid rgba(255,255,255,.11);
            border-radius: 8px;
            padding: 1.3rem 1.4rem;
            background: linear-gradient(135deg, rgba(22, 32, 52, .92), rgba(9, 14, 24, .86));
            box-shadow: 0 18px 55px rgba(0,0,0,.32);
            margin-bottom: 1rem;
        }
        .hero h1 {
            font-size: clamp(2rem, 4vw, 4rem);
            line-height: 1.02;
            margin: 0;
            color: white;
        }
        .hero p {
            color: #aebbd0;
            margin: .65rem 0 0 0;
            font-size: 1.03rem;
            max-width: 72rem;
        }
        .chips { display: flex; gap: .5rem; flex-wrap: wrap; margin-top: 1rem; }
        .chip {
            color: #e9f6ff;
            border: 1px solid rgba(255,255,255,.14);
            background: rgba(255,255,255,.06);
            padding: .35rem .7rem;
            border-radius: 999px;
            font-size: .82rem;
        }
        .card {
            min-height: 116px;
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 8px;
            background: linear-gradient(180deg, rgba(23, 32, 51, .88), rgba(10, 15, 24, .84));
            padding: 1rem;
        }
        .label { color: #9dafc8; text-transform: uppercase; font-size: .78rem; letter-spacing: .04rem; }
        .value { color: white; font-size: 1.75rem; font-weight: 850; margin-top: .3rem; }
        .hint { color: #8494ad; font-size: .84rem; margin-top: .3rem; }
        .insight {
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 8px;
            background: rgba(18, 27, 43, .82);
            padding: 1rem;
            margin-bottom: .75rem;
        }
        .stButton>button {
            width: 100%;
            min-height: 3rem;
            border: 0;
            border-radius: 8px;
            background: linear-gradient(90deg, #00c2ff, #67f2a2);
            color: #04111c;
            font-weight: 850;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


@st.cache_data(show_spinner=False)
def load_data() -> pd.DataFrame:
    df = pd.read_csv(DATA_PATH)
    df["price_per_mile"] = np.where(df["distance"] > 0, df["price"] / df["distance"], 0)
    return df


@st.cache_resource(show_spinner=False)
def load_model():
    return joblib.load(MODEL_PATH)


def hero(title: str, subtitle: str, chips: list[str]) -> None:
    chip_html = "".join(f"<span class='chip'>{c}</span>" for c in chips)
    st.markdown(
        f"<div class='hero'><h1>{title}</h1><p>{subtitle}</p><div class='chips'>{chip_html}</div></div>",
        unsafe_allow_html=True,
    )


def kpi(label: str, value: str, hint: str) -> None:
    st.markdown(
        f"<div class='card'><div class='label'>{label}</div><div class='value'>{value}</div><div class='hint'>{hint}</div></div>",
        unsafe_allow_html=True,
    )


def tune(fig: go.Figure, height: int = 420) -> go.Figure:
    fig.update_layout(
        height=height,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#dce8f7"),
        margin=dict(l=20, r=20, t=55, b=25),
        legend=dict(orientation="h", y=1.06),
    )
    fig.update_xaxes(gridcolor="rgba(255,255,255,.08)")
    fig.update_yaxes(gridcolor="rgba(255,255,255,.08)")
    return fig


def filtered_data(df: pd.DataFrame):
    with st.sidebar:
        st.markdown("### Cab Surge App")
        page = st.radio(
            "Navigation",
            ["Home", "Dashboard", "Prediction", "Clustering", "Business Insights"],
            label_visibility="collapsed",
        )
        st.markdown("---")
        st.markdown("### Filters")
        brands = st.multiselect("Cab Type", sorted(df["cab_type"].unique()), default=sorted(df["cab_type"].unique()))
        services = st.multiselect("Service", sorted(df["name"].unique()), default=sorted(df["name"].unique()))
        days = st.multiselect("Day", DAY_ORDER, default=DAY_ORDER)
        hours = st.slider("Hour", 0, 23, (0, 23))

    filtered = df[
        df["cab_type"].isin(brands)
        & df["name"].isin(services)
        & df["Day_of_Week_Name"].isin(days)
        & df["hour"].between(hours[0], hours[1])
    ].copy()
    return page, filtered


def show_kpis(df: pd.DataFrame) -> None:
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        kpi("Records", f"{len(df):,}", "Filtered trip rows")
    with c2:
        kpi("Average Price", f"${df['price'].mean():.2f}", "Historical fare")
    with c3:
        kpi("Average Surge", f"{df['surge_multiplier'].mean():.2f}x", "Surge multiplier")
    with c4:
        kpi("Demand", f"{df['ride_count'].sum():,}", "Total ride count")


def model_score(model, df: pd.DataFrame) -> tuple[float, float]:
    sample = df.dropna(subset=MODEL_FEATURES + ["price"]).copy()
    train, test = train_test_split(sample, test_size=.2, random_state=42)
    pred = model.predict(test[MODEL_FEATURES])
    return r2_score(test["price"], pred), mean_absolute_error(test["price"], pred)


def home(df: pd.DataFrame, model) -> None:
    hero(
        "Cab Surge Price Predictor",
        "A modern Streamlit frontend powered by your trained cab fare prediction pipeline, with analytics, clustering, and business recommendations.",
        ["Saved ML Pipeline", "Decision Tree Regressor", "Plotly Dashboard", "K-Means Segments"],
    )
    show_kpis(df)
    left, right = st.columns([1.25, 1])
    with left:
        hourly = df.groupby("hour", as_index=False).agg(price=("price", "mean"), surge=("surge_multiplier", "mean"), demand=("ride_count", "sum"))
        fig = px.line(hourly, x="hour", y=["price", "surge"], markers=True, title="Hourly Price and Surge Trend", color_discrete_sequence=["#00c2ff", "#ff5c7c"])
        st.plotly_chart(tune(fig), use_container_width=True)
    with right:
        r2, mae = model_score(model, df)
        st.markdown("### Model Check")
        st.metric("R2 Score", f"{r2:.3f}")
        st.metric("Mean Absolute Error", f"${mae:.2f}")
        st.metric("Input Features", f"{len(MODEL_FEATURES)}")


def dashboard(df: pd.DataFrame) -> None:
    hero("Analytics Dashboard", "Explore price behavior, demand movement, route concentration, and weather-linked surge patterns.", ["KPI Cards", "Heatmaps", "Route View", "Weather Signals"])
    show_kpis(df)
    tab1, tab2, tab3 = st.tabs(["Pricing", "Demand", "Routes"])

    with tab1:
        c1, c2 = st.columns(2)
        with c1:
            service = df.groupby("name", as_index=False)["price"].mean().sort_values("price", ascending=False)
            fig = px.bar(service, x="name", y="price", color="price", title="Average Price by Service", color_continuous_scale="Tealrose")
            st.plotly_chart(tune(fig), use_container_width=True)
        with c2:
            fig = px.box(df, x="cab_type", y="price", color="cab_type", title="Price Distribution by Cab Type", color_discrete_sequence=["#00c2ff", "#67f2a2"])
            st.plotly_chart(tune(fig), use_container_width=True)
        heat = df.pivot_table(index="Day_of_Week_Name", columns="hour", values="price", aggfunc="mean").reindex(DAY_ORDER)
        fig = px.imshow(heat, aspect="auto", title="Price Heatmap by Day and Hour", color_continuous_scale="Turbo")
        st.plotly_chart(tune(fig, 455), use_container_width=True)

    with tab2:
        c1, c2 = st.columns(2)
        with c1:
            demand = df.groupby("hour", as_index=False)["ride_count"].sum()
            fig = px.area(demand, x="hour", y="ride_count", title="Demand by Hour", color_discrete_sequence=["#67f2a2"])
            st.plotly_chart(tune(fig), use_container_width=True)
        with c2:
            fig = px.scatter(df.sample(min(len(df), 5000), random_state=7), x="rain", y="surge_multiplier", size="ride_count", color="cab_type", hover_data=["name", "route"], title="Rainfall vs Surge", color_discrete_sequence=["#00c2ff", "#ff5c7c"])
            st.plotly_chart(tune(fig), use_container_width=True)

    with tab3:
        route = df.groupby("route", as_index=False).agg(avg_price=("price", "mean"), demand=("ride_count", "sum"), avg_distance=("distance", "mean"), price_per_mile=("price_per_mile", "mean"))
        top = route.sort_values("demand", ascending=False).head(15)
        fig = px.bar(top, y="route", x="demand", color="avg_price", orientation="h", title="Top Routes by Demand", color_continuous_scale="Viridis")
        fig.update_layout(yaxis=dict(autorange="reversed"))
        st.plotly_chart(tune(fig, 550), use_container_width=True)
        st.dataframe(route.sort_values("avg_price", ascending=False).head(20).round(2), hide_index=True, use_container_width=True)


def prediction(df: pd.DataFrame, model) -> None:
    hero("Live Fare Prediction", "Use the exact feature schema from your saved model pipeline to predict cab fare instantly.", ["Real PKL Model", "Scaler", "One-Hot Encoder", "Decision Tree"])
    c1, c2, c3 = st.columns(3)
    with c1:
        cab_type = st.selectbox("Cab Type", ["Lyft", "Uber"])
        available = sorted(df.loc[df["cab_type"] == cab_type, "name"].unique())
        service = st.selectbox("Service Name", available)
        day = st.selectbox("Day of Week", DAY_ORDER)
    with c2:
        hour = st.slider("Hour", 0, 23, 8)
        distance = st.number_input("Distance", min_value=.02, max_value=10.0, value=2.2, step=.05)
        rush = 1 if hour in [7, 8, 9, 16, 17, 18, 19] else 0
        is_rush_hour = st.selectbox("Rush Hour", [rush, 1 - rush], format_func=lambda x: "Yes" if x == 1 else "No")
    with c3:
        temp = st.slider("Temperature", 20.0, 100.0, 64.0, .5)
        rain = st.number_input("Rain", min_value=0.0, max_value=2.0, value=0.0, step=.01)
        clouds = st.slider("Clouds", 0.0, 100.0, 35.0, 1.0)

    input_df = pd.DataFrame([{
        "distance": distance,
        "temp": temp,
        "rain": rain,
        "clouds": clouds,
        "hour": hour,
        "is_rush_hour": is_rush_hour,
        "cab_type": cab_type,
        "name": service,
        "Day_of_Week_Name": day,
    }])

    if st.button("Predict Cab Price"):
        pred = float(model.predict(input_df[MODEL_FEATURES])[0])
        avg = df["price"].mean()
        a, b, c = st.columns(3)
        a.metric("Predicted Price", f"${pred:.2f}", f"{pred - avg:+.2f} vs avg")
        b.metric("Price per Mile", f"${pred / distance:.2f}")
        c.metric("Rush Hour", "Yes" if is_rush_hour else "No")
        st.dataframe(input_df, hide_index=True, use_container_width=True)


def clustering(df: pd.DataFrame) -> None:
    hero("Clustering Analysis", "Segment trips by price, distance, surge, weather, and demand to reveal business patterns.", ["K-Means", "Customer Segments", "Fare Strategy"])
    n = st.slider("Number of Clusters", 3, 6, 4)
    features = ["price", "distance", "surge_multiplier", "rain", "clouds", "ride_count"]
    scaled = StandardScaler().fit_transform(df[features])
    clustered = df.copy()
    clustered["cluster"] = KMeans(n_clusters=n, random_state=42, n_init=10).fit_predict(scaled).astype(str)
    c1, c2 = st.columns([1.2, 1])
    with c1:
        fig = px.scatter(clustered.sample(min(len(clustered), 6000), random_state=9), x="distance", y="price", color="cluster", size="ride_count", hover_data=["cab_type", "name", "route"], title="Trip Clusters by Distance and Price")
        st.plotly_chart(tune(fig, 520), use_container_width=True)
    with c2:
        profile = clustered.groupby("cluster", as_index=False).agg(records=("cluster", "count"), avg_price=("price", "mean"), avg_surge=("surge_multiplier", "mean"), avg_distance=("distance", "mean"), demand=("ride_count", "sum"))
        st.dataframe(profile.round(2), hide_index=True, use_container_width=True)


def insights(df: pd.DataFrame) -> None:
    hero("Business Insights", "Fast, presentation-ready recommendations from the model dataset and dashboard analytics.", ["Pricing", "Operations", "Passenger Timing", "Growth"])
    peak_hour = int(df.groupby("hour")["ride_count"].sum().idxmax())
    top_route = df.groupby("route")["ride_count"].sum().idxmax()
    premium = df.groupby("name")["price"].mean().idxmax()
    rain_corr = df["rain"].corr(df["surge_multiplier"])
    items = [
        ("Peak operations window", f"Demand peaks around hour {peak_hour}. Keep driver supply and incentives strongest around this window."),
        ("High-value service", f"{premium} has the highest average price. Use premium positioning and targeted promotions for this service."),
        ("Route focus", f"The busiest route is {top_route}. Monitor this route for availability, wait time, and surge sensitivity."),
        ("Weather signal", f"Rain-to-surge correlation is {rain_corr:.3f}. Weather alerts can support proactive supply planning."),
    ]
    for title, text in items:
        st.markdown(f"<div class='insight'><b>{title}</b><br>{text}</div>", unsafe_allow_html=True)
    service = df.groupby(["cab_type", "name"], as_index=False).agg(demand=("ride_count", "sum"), avg_price=("price", "mean"))
    fig = px.treemap(service, path=["cab_type", "name"], values="demand", color="avg_price", color_continuous_scale="Tealrose", title="Demand Share by Cab Type and Service")
    st.plotly_chart(tune(fig, 540), use_container_width=True)


def main() -> None:
    css()
    if not DATA_PATH.exists() or not MODEL_PATH.exists():
        st.error("Dataset or model file is missing. Check the dataset and model folders.")
        st.stop()
    df = load_data()
    model = load_model()
    page, active = filtered_data(df)
    if active.empty:
        st.warning("No rows match the selected filters.")
        st.stop()
    if page == "Home":
        home(active, model)
    elif page == "Dashboard":
        dashboard(active)
    elif page == "Prediction":
        prediction(df, model)
    elif page == "Clustering":
        clustering(active)
    else:
        insights(active)


if __name__ == "__main__":
    main()
