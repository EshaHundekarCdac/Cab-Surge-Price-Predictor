# Pages

Navigation is handled inside `app.py` for a single polished Streamlit entry point.
