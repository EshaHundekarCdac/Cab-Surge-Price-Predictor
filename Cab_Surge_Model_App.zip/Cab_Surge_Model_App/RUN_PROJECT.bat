@echo off
cd /d "%~dp0"
echo Installing project requirements...
pip install -r requirements.txt
echo.
echo Launching Cab Surge Price Predictor...
streamlit run app.py
